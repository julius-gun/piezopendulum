# piezopendulum
Development of a Self-Sensing  Piezoelectrically Actuated Pendulum
